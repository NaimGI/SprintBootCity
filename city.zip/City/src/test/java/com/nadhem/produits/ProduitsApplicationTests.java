package com.nadhem.produits;



import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.nadhem.produits.entities.City;
import com.nadhem.produits.entities.Country;



@SpringBootTest
class CityApplicationTests {
}
